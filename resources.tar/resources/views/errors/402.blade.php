@extends('errors::minimal')

@section('title', __('messages.t_payment_required_title'))
@section('code', '402')
@section('message', __('messages.t_payment_required_message'))

