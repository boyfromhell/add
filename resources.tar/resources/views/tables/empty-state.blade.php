<div class="text-center p-6">
    <img src="/images/not-found.svg" alt="No records found" class="mx-auto w-40">
    <h4 class="fi-ta-empty-state-heading text-base font-semibold leading-6 text-gray-950 dark:text-white">
        {{ $message }}
    </h4>
</div>
