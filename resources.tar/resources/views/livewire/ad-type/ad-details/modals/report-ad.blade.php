<x-filament::modal id="report-ad" width="xl" close-button="false">
    {{-- Header --}}
    <x-slot name="heading">{{ __('messages.t_report_this_ad') }}</x-slot>
    <div>
        <form wire:submit="reportAd">
            {{ $this->form }}

            <div class="mt-4">
                <x-filament::button type="submit">
                    {{ __('messages.t_report_ad') }}
                </x-filament::button>
            </div>
        </form>
    </div>
    <div
    @class([
        'absolute',
        'end-4 top-4'
    ])
    >
    <x-filament::icon-button
        color="gray"
        icon="heroicon-o-x-mark"
        icon-alias="modal.close-button"
        icon-size="lg"
        :label="__('filament::components/modal.actions.close.label')"
        tabindex="0"
        x-on:click="$dispatch('close-modal', { id: 'report-ad' })"
        class="fi-modal-close-btn"
    />
    </div>
</x-filament::modal>
