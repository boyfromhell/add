@if (isMapViewShowFilterPopup())
<div :class="{'w-0 h-0':showFullScreenMap}">
    <!-- Filter modal  -->
    <x-filament::modal id="ad-filter-modal" width="xl" x-cloak>
        <x-slot name="heading">
            {{ __('messages.t_filter') }}
        </x-slot>
        <div>
            @include('livewire.ad-type._parties.filter-by-ad')
        </div>
    </x-filament::modal>
</div>
@endif