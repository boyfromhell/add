<li class="animate-pulse mt-1 h-[38px]">
    <div class="w-20 py-2 ml-4">
        <a class="bg-gray-200 dark:bg-gray-600 block text-sm rounded-full px-3 h-3"> &nbsp; </a>
    </div>
</li>
