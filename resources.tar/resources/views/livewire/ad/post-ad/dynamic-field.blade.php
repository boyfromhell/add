<div>
    <form wire:submit>
        {{ $this->form }}
    </form>

    <x-filament-actions::modals />
</div>
